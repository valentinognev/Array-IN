# Inertial Navigation Using an Inertial Sensor Array

Code and data.
