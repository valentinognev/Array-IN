function g = get_norm_g_kth()

g = 9.8183037; %  Lantmateriet, m/s^2

end