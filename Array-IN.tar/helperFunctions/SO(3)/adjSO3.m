function adw = adjSO3(w)

adw = HatSO3(w);