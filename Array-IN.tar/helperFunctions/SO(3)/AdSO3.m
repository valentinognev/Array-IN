function AdR = AdSO3(R)

AdR = R;
